package com.example.u02_s1;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Button;

public class menu extends AppCompatActivity implements View.OnClickListener, View.OnKeyListener,
View.OnTouchListener {

    TextView tvRes;
    Button btForm, btBD;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);


        //Recupero e textView de la interfaz
        tvRes = findViewById(R.id.tvRes);
        //HACERLO NO VISIBLE
       tvRes.setVisibility(View.INVISIBLE);

        //recupero los botones de la interfaz y de la imagen
        btForm = findViewById(R.id.btForm);
        btBD = findViewById(R.id.btBD);
        imageView = findViewById(R.id.fondoFoc);

        //asignacion de los liseers de teclado
        btForm.setOnKeyListener(this);
        btBD.setOnKeyListener(this);

        //asignamos el lisener al toque de la imagen
        imageView.setOnTouchListener(this);


    }

    @Override
    public void onClick(View v) {



        //si han hecho click en el boton formulario
    if (v.getId()==R.id.btForm){
        //voy a la ventana de la actividad principal
        //creo un intent
        Intent intent = new Intent(this, MainActivity.class);
        //inicir la actividad que hay en el intent
        startActivity(intent);

    }
    else if (v.getId()==R.id.btBD){
        //capturo el boton que se ha pulsado
        Button btPulsado = (Button) v;
        // le asigno el texto al boton textView
        tvRes.setText(btPulsado.getText());
        tvRes.setVisibility(View.VISIBLE);

    }
    }

    @Override
    public boolean onKey(View v, int KeyCode, KeyEvent event) {
        //si hemos manejado el evento devolvemos true si no false
        boolean hecho = false;

        //control de la tecla que se ha pulsado
        switch (KeyCode){
            case KeyEvent.KEYCODE_F:
            case KeyEvent.KEYCODE_1:
                //creo un intent
                Intent intent = new Intent(this, MainActivity.class);
                //inicir la actividad que hay en el intent
                startActivity(intent);
                hecho = true;
                break;

            case KeyEvent.KEYCODE_B:
            case KeyEvent.KEYCODE_2:
                //COJO EL TEXTO DEL BOTON Que se ha pulsado
                tvRes.setText(btBD.getText());
                tvRes.setVisibility(View.VISIBLE);
                hecho = true;
                break;
        }

        return hecho;
    }

    @Override
    public boolean onTouch(View v, MotionEvent motionEvent) {

        //si hemos manejado el evento devolvemos true si no false
        boolean hecho = false;
        //TV VISIBLE
        tvRes.setVisibility(View.VISIBLE);


        switch (motionEvent.getAction()){
            //pulsar la pantalla
            case MotionEvent.ACTION_DOWN:
                tvRes.setVisibility(View.VISIBLE);

                tvRes.setText("Pulsado en X = "+ motionEvent.getX() + " Y= " + motionEvent.getY());
                hecho = true;
                break;
                //levantar el dedo de la pantalla que dejo de pulsar
            case MotionEvent.ACTION_UP:
                tvRes.setVisibility(View.VISIBLE);

                tvRes.setText("levantado en X = "+ motionEvent.getX() + " Y= " + motionEvent.getY());
                hecho = true;
                break;

                //arrastrar pantalla
            case MotionEvent.ACTION_MOVE:
                tvRes.setVisibility(View.VISIBLE);

                tvRes.setText("Arrastrado por X = " +motionEvent.getX() + " Y= " + motionEvent.getY());
                hecho = true;
                break;

        }


        return hecho;
    }
}